import {applyMiddleware,createStore} from "redux";
import {rootReducer} from "./root.reducer";
import {composeWithDevTools} from 'redux-devtools-extension';
/*import logger from "redux";*/
import thunk from "redux-thunk";

let store=createStore(rootReducer,composeWithDevTools(applyMiddleware(thunk)));
export {store};

