import {FETCH_COURSE_FAILURE, FETCH_COURSE_REQUEST, FETCH_COURSE_SUCCESS} from "./courses.actionTypes";
export const COURSE_FEATURE_KEY ='courses';
let initialState={
    loading:'false',
    courses:[],
    errorMsg:''
};
let courseReducer=(state=initialState , action:any)=>{
    let {type , payload} = action;
    switch(type) {
        case FETCH_COURSE_REQUEST :
            return {
                ...state,
                loading : true
            };
        case FETCH_COURSE_SUCCESS:
            return{
                ...state,
                loading: false,
                courses: payload
            };
        case FETCH_COURSE_FAILURE:
            return{
                ...state,
                loading:false,
                errorMsg: payload
            };
        default: return  state;
    }
};
export {courseReducer};